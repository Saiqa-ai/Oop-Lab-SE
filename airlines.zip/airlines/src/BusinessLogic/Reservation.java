/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BusinessLogic;

import FlightReservationSystem.Loginpage;




public class Reservation {
    private Loginpage user;
    private Flight flight;
    private Seat seat;
   

    public Reservation(Loginpage user, Flight flight, Seat seat) {
        this.user = user;
        this.flight = flight;
        this.seat = seat;
    }

    
    public Loginpage getUser() {
        return user;
    }

    public void setUser(Loginpage user) {
        this.user = user;
    }

    public Flight getFlight() {
        return flight;
    }

    public void setFlight(Flight flight) {
        this.flight = flight;
    }

    public Seat getSeat() {
        return seat;
    }

    public void setSeat(Seat seat) {
        this.seat = seat;
    }

    public void setStatus(String paid) {
        throw new UnsupportedOperationException("Not supported yet."); 
    }

    public String getId() {
        throw new UnsupportedOperationException("Not supported yet."); 
    }

    
}