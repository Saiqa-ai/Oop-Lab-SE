
package BusinessLogic;


import FileHandling.FileHandler;
import java.io.IOException;

public class FileManager {
    
    private FileHandler fd;

    public FileManager() {
        fd = new FileHandler();
    }
    
    public void createFile(String fileName) {
        fd.createFile(fileName);
    }
    
    public String readFile(String fileName) throws IOException {
        return fd.ReadFile(fileName);
    }

    
    public void updateFile(String fileName, String newContent) {
        fd.update(fileName, newContent);
    }
    
    public void deleteFile(String fileName) {
        fd.delete(fileName);
    }
    
    public void add(String m,String fileName)
    {
        fd.ADD(m,fileName);
    }
    
    public void deleteLine(String id,String fileName)
    {
        fd.deleteLine(id,fileName);
    }
    public void updateLine(String dataToUpdate, String newData,String fileName)
    {
        fd.updateLine(dataToUpdate, newData,fileName);
     
    }
}
