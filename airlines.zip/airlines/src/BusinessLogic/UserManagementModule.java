/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BusinessLogic;


import FlightReservationSystem.Loginpage;
import java.util.ArrayList;
import java.util.List;

public class UserManagementModule {
    private List<Loginpage> registeredUsers;

    public UserManagementModule() {
        registeredUsers = new ArrayList<>();
    }

    public boolean login(String username, String password) {
        for (Loginpage user : registeredUsers) {
            if (user.getUsername().equals(username) && user.getPassword().equals(password)) {
                System.out.println("Login successful!");
                return true;
            }
        }
        System.out.println("Invalid username or password. Login failed.");
        return false;
    }

    public void register(Loginpage user) {
        registeredUsers.add(user);
        System.out.println("User registered successfully!");
    }
    
    public void logout(Loginpage user) {
        System.out.println("User " + user.getUsername() + " logged out.");
    }
    
   
}
