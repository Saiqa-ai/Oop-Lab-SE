
package FileHandling;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.io.BufferedWriter;
import java.util.logging.Level;
import java.util.logging.Logger;

public class FileHandler {

    public void createFile(String FileName)
    {
        File f=new File(FileName);
        try {
            if(f.createNewFile())
            {
                System.out.println("File craeted: "+f.getName());
            }
            else
            {
                System.out.println("File Already Exits");
            }
        } catch (IOException ex) {
            System.out.println("An Error Occured");
            Logger.getLogger(FileHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void ADD(String m,String fileName)
    {
    FileWriter fw;
        try {
            fw=new FileWriter(fileName,true);
        fw.append(m);
        fw.close();
            System.out.println("adddddddddddddddded");
       
        } catch (IOException ex) {
            System.out.println("error");
        }
    }
    
       public void deleteLine(String dataToDelete ,String fileName) {
        try {
            File inputFile = new File(fileName);
            File tempFile = new File("temp.txt");

            BufferedReader reader = new BufferedReader(new FileReader(inputFile));
            FileWriter writer = new FileWriter(tempFile);

            String line;
            boolean deleted = false;
            while ((line = reader.readLine()) != null) {
                // Check if the line contains the data to be deleted
                if (!line.contains(dataToDelete)) {
                    writer.write(line + System.lineSeparator());
                } else {
                    deleted = true;
                }
            }

            writer.close();
            reader.close();

            if (deleted) {
                inputFile.delete();
                tempFile.renameTo(inputFile);
                System.out.println("Data '" + dataToDelete + "' deleted successfully from the file.");
            } else {
                tempFile.delete();
                System.out.println("Data '" + dataToDelete + "' not found in the file.");
            }
        } catch (IOException ex) {
            System.out.println("An error occurred: " + ex.getMessage());
        }
    }
       
       
public void updateLine(String dataToUpdate, String newData, String fileName) {
    try {
        File inputFile = new File(fileName);
        File tempFile = new File("temp.txt");

        BufferedReader reader = new BufferedReader(new FileReader(inputFile));
        FileWriter writer = new FileWriter(tempFile);

        String line;
        boolean updated = false;
        while ((line = reader.readLine()) != null) {
            if (line.contains(dataToUpdate)) {
                line = newData;
                updated = true;
                System.out.println("Line replaced: " + line);
            }
            writer.write(line + System.lineSeparator());
        }

        writer.close();
        reader.close();

        if (updated) {
            inputFile.delete();
            tempFile.renameTo(inputFile);
            System.out.println("Data '" + dataToUpdate + "' updated successfully in the file.");
        } else {
            tempFile.delete();
            System.out.println("Data '" + dataToUpdate + "' not found in the file.");
        }
    } catch (IOException ex) {
        System.out.println("An error occurred: " + ex.getMessage());
    }
}
    
  public String ReadFile(String FileName) throws IOException {
      String mm = null;
    StringBuilder c = new StringBuilder();
    File f = new File(FileName);
    try {
        FileReader R = new FileReader(f);
        int chr;
        while ((chr = R.read()) != -1) {
            c.append((char) chr);
             mm=String.valueOf(c);
        }
        R.close();
    } catch (FileNotFoundException ex) {
        System.out.println("Error occured");
        Logger.getLogger(FileHandler.class.getName()).log(Level.SEVERE, null, ex);
    }   
      System.out.println(""+c);
        return mm;
}
  
  public void update(String fileName, String newContent) {
    File f = new File(fileName);
    try {
        FileWriter W = new FileWriter(f);
        W.write(newContent);
        W.close();
    } catch (IOException ex) {
        Logger.getLogger(FileHandler.class.getName()).log(Level.SEVERE, null, ex);
    }
}
  
  public void delete(String FileName)
  {
      File f =new File(FileName);
      if(f.delete())
      {
          System.out.println("File deleted: "+f.getName());
      }
      else
      {
          System.out.println("Failed");
      }
              
  }

    public String readFile(String fileName) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public void readline(String string, String fileName) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public String readline(String fileName) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public void add(String fd, String fileName) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}