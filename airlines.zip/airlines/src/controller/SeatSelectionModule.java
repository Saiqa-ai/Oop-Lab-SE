/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import BusinessLogic.Flight;
import BusinessLogic.Reservation;
import BusinessLogic.Seat;
import java.util.ArrayList;
import java.util.List;

public class SeatSelectionModule {
    private List<Seat> availableSeats;

    public SeatSelectionModule() {
        availableSeats = new ArrayList<>();
    }

    public List<Seat> getAvailableSeats(Flight flight) {
        List<Seat> availableSeatsForFlight = new ArrayList<>();
        for (Seat seat : availableSeats) {
            if (seat.isAvailable() && isSeatMatchingFlight(seat, flight)) {
                availableSeatsForFlight.add(seat);
            }
        }
        return availableSeatsForFlight;
    }

    private boolean isSeatMatchingFlight(Seat seat, Flight flight) {
        // Add your implementation to check if the seat matches the flight's criteria (e.g., flight number, class, etc.)
        return true;
    }

    public void selectSeat(Reservation reservation, Seat seat) {
        if (seat.isAvailable()) {
            seat.setAvailable(false);
            reservation.setSeat(seat);
            System.out.println("Seat " + seat.getSeatNumber() + " selected for reservation.");
        } else {
            System.out.println("Seat " + seat.getSeatNumber() + " is not available.");
        }
    }

    // Other seat selection methods and functionality as needed
}