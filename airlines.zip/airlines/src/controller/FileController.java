
package controller;


import BusinessLogic.FileManager;
import java.io.IOException;

public class FileController {
    private FileManager fileManager;

    public FileController() {
        fileManager = new FileManager();
    }

    public void createFile(String fileName) {
        fileManager.createFile(fileName);
    }

    public String readFile(String fileName) throws IOException {
        return fileManager.readFile(fileName);
    }

    public void updateFile(String fileName, String newContent) {
        fileManager.updateFile(fileName, newContent);
    }

    public void deleteFile(String fileName) {
        fileManager.deleteFile(fileName);
    }
    
    public void add(String m,String fileName)
    {
        fileManager.add(m,fileName);
    }
    
     public void deleteLine(String m,String fileName)
    {
        fileManager.deleteLine(m,fileName);
    }
     
    public void updateLine(String dataToUpdate, String newData,String fileName)
    {
        fileManager.updateLine(dataToUpdate, newData,fileName);
    }

//    }

    public void readFile(String string, String fileName) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public void readline(String string, String fileName) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public String readline(String fileName) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
