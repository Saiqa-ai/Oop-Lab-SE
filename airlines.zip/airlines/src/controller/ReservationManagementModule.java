/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import BusinessLogic.Flight;
import BusinessLogic.Reservation;
import BusinessLogic.Seat;
import FlightReservationSystem.Loginpage;

import java.util.ArrayList;
import java.util.List;

public class ReservationManagementModule {
    private List<Reservation> reservations;

    public ReservationManagementModule() {
        reservations = new ArrayList<>();
    }

    public void createReservation(Loginpage user, Flight flight, Seat seat) {
        Reservation reservation = new Reservation(user, flight, seat);
        reservations.add(reservation);
        System.out.println("Reservation created successfully. Reservation ID: " + reservation.getId());
    }

    public Reservation getReservationById(String reservationId) {
        for (Reservation reservation : reservations) {
            if (reservation.getId().equals(reservationId)) {
                return reservation;
            }
        }
        return null;
    }

    public void updateReservation(Reservation reservation) {
        // Add your implementation to update the reservation details
        System.out.println("Reservation updated successfully. Reservation ID: " + reservation.getId());
    }

    public void deleteReservation(Reservation reservation) {
        reservations.remove(reservation);
        System.out.println("Reservation deleted successfully. Reservation ID: " + reservation.getId());
    }

    
}
